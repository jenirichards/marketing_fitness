# Harbour Fitness ("b-ascent") — App Icon Suite

Generated from `b-ascent-icon.svg` and `b-ascent-lockup.svg`.

## ios/AppIcon.appiconset/

Drop this whole folder into Xcode (replace the existing `AppIcon.appiconset` in
`Assets.xcassets`) — `Contents.json` is already wired up to every file.

- Full legacy set covering iPhone + iPad at all required point sizes/scales
  (20, 29, 40, 60, 76, 83.5pt @1x/2x/3x).
- `AppIcon-1024x1024@1x.png` is the App Store Connect marketing icon.
- All PNGs are flattened with **no alpha channel**, per Apple's requirement —
  corners are square/full-bleed; iOS applies the rounded-square mask itself,
  so don't re-round these.
- Note: if your project targets Xcode 14+ only, a single 1024×1024 icon in a
  "single size" asset catalog is technically sufficient — Xcode generates the
  rest at build time. This folder gives you the full explicit set for maximum
  compatibility (older Xcode, fastlane/CI icon linting, etc.).

## android/

Drop the `mipmap-*` folders into `app/src/main/res/`.

- `mipmap-{mdpi,hdpi,xhdpi,xxhdpi,xxxhdpi}/ic_launcher.png` — legacy square
  launcher icon (48–192px).
- `mipmap-*/ic_launcher_round.png` — pre-cropped circular variant for
  launchers that don't apply their own adaptive mask.
- `mipmap-*/ic_launcher_foreground.png` + `ic_launcher_background.png` —
  Adaptive Icon layers (Android 8.0+/API 26+), sized per density on the
  108dp canvas. Artwork is kept inside the 66dp safe zone so it survives
  circle/squircle/rounded-square masking on different launchers.
- `mipmap-anydpi-v26/ic_launcher.xml` + `ic_launcher_round.xml` — the
  adaptive-icon XML that references the two layers above. Already correct;
  no edits needed unless your resource names differ.

## store-listing/

- `app-store-icon-1024x1024.png` — upload in App Store Connect (App
  Information → App Store icon).
- `play-store-icon-512x512.png` — upload in Play Console (Store presence →
  Main store listing → App icon).

## marketing-lockup/

Bonus renders of the horizontal "HarbourFitness" wordmark lockup at 1x/2x/3x,
in both the light-background and dark-background colour variants the source
SVG defined. Handy for store-listing screenshots, README headers, decks, etc.
— not required by either store.

## source-svgs/

The editable SVG sources used to generate everything above, in case you need
to tweak colours/proportions and regenerate:

- `flat-icon.svg` — square, full-bleed, no baked-in corner radius (the base
  for all iOS/Android renders).
- `icon-rounded.svg` — your original rounded-square icon, unchanged.
- `adaptive-background.svg` / `adaptive-foreground.svg` — the two Android
  adaptive icon layers.
- `lockup-light.svg` / `lockup-dark.svg` — the wordmark lockup in each
  colour variant.
